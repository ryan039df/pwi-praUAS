from django.apps import AppConfig

class UTSConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "uts"
