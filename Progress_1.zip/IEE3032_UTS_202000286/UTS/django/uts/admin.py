from django.contrib import admin
from .models import Sensor, Sensor2, Sensor3, Actuator

admin.site.register(Sensor)
admin.site.register(Sensor2)
admin.site.register(Sensor3)
admin.site.register(Actuator)
